const DATABASE_NAME = 'fatec_aula.db';
const CREATE_TABLE_CLIENTE =
    "CREATE TABLE cliente(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nome TEXT, email TEXT, tipo TEXT, sincronizado INTEGER)";
