class AppRoutes {
  static const PAGE_PRINCIPAL = '/';
  static const PAGE_CLIENTES = '/clientes';
  static const PAGE_EDIT = '/cliente-edit';
  static const PAGE_ADD = '/cliente-add';
}
